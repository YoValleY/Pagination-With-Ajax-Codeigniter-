<!DOCTYPE html>
<html lang="en">
<!-- view file -->
<head>
	<title>Pagination With AJAX (Codeigniter)</title>
	<script src="<?php echo base_url(); ?>assets/bootstrap/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/bootstrap/bootstrap.min.js"></script>
	<link href="<?php echo base_url(); ?>assets/bootstrap/bootstrap.min.css" type="text/css" rel="stylesheet"/>	
	<style type="text/css">
	a {
		padding-left: 5px;
		padding-right: 5px;
		margin-left: 5px;
		margin-right: 5px;
	}
	</style>
</head>
<body style="">
<div class="col-md-12">
<!-- header file-->
	<?php include("Header.php");?>
</div>

<div class="col-md-12">
	<h1>Pagination With AJAX (Codeigniter)</h1>
</div>
<div class="col-md-8">	
	<table class="table table-hover table-bordered"  id='news_data'>
		<thead>
		<tr>
			<th>S.no</th>
			<th>Title</th>
			<th>Content</th>
		</tr>
		</thead>
		<tbody></tbody>
	</table>

	<!-- Pagination -->
	<div style='margin-top: 10px;' id='pagination'></div>
</div>
	<script src="<?php echo base_url() ?>assets/js/jquery-3.3.1.js"></script>
	<script src="<?php echo base_url() ?>assets/bootstrap/bootstrap.min.js"></script>
	<!--- jquery and bootstrap file -->
	<script type='text/javascript'>

		$(document).ready(function(){
			/* click event occurs and our this code excute */
			$('#pagination').on('click','a',function(e){
				e.preventDefault(); 
				var page_no = $(this).attr('data-ci-pagination-page');
				load(page_no);
			});
			load(0);
			// this function featch data from db and send control to my_data function with two arguments.
			function load(pagno){ 
				$.ajax({
					url: '<?=base_url()?>index.php/News/featchNews/'+pagno,
					type: 'get', 
					dataType: 'json', 
					success: function(response){ 
						console.log(response);
						$('#pagination').html(response.pagination);
						my_data(response.result,response.row);
					}
				});
			}
			//after click event this data going to append to table 
			function my_data(result,j){
				console.log(result);
				
				var length = result.length;
				console.log(length);
				
				j = Number(j);
				$('#news_data tbody').empty();
				
				for(var i = 0 ; i < length; i++){
					j+=1;
					var tr = "<tr>";
					tr += "<td>"+ j +"</td>";
					tr += "<td><a href='"+ result[i].link +"' target='_blank' >"+result[i].title +"</a></td>";
					tr += "<td>"+ result[i].content +"</td>";
					tr += "</tr>";
					$('#news_data tbody').append(tr);
				}
			}
		});
	</script>
</body>
</html>