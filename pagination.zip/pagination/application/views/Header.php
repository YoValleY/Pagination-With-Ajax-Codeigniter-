<style>
<!-- My Header file -->
.header{
	color: white;
    background: black;
    padding: 10px;
    width: 65%;
}
.header-text{
	    margin-left: 254px;
}
</style>
<div class="header">
<h1 class="header-text">Yog Valley</h1>
</div>