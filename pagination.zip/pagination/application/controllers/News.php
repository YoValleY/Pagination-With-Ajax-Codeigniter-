<?php
defined('BASEPATH') OR exit('No direct script access allowed');
// This is my controller names as news 

class News extends CI_Controller {

	public function __construct(){
		
        parent::__construct();
		// helper is load here that is url.
        $this->load->helper('url');
		// library is loaded here
		// pagination library is stored in or located in sysytem file -> library
		$this->load->library('pagination');
		$this->load->model('My_model'); //model
		
	}
	// now we create here index function.
	public function index(){
		//news_list is our view page.
		$this->load->view('news_list');
	}

	public function featchNews($rowno=0){

		// Row per page
		$rowperpage = 5; // we can asign the number of data has been show on page at a time

		// Row position
		if($rowno != 0){
			$rowno = ($rowno-1) * $rowperpage;
		}
      	
      	// All records count
      	$allcount = $this->My_model->getrecordCount();

      	// Get  records
		//here we featch our data from model file 
      	$users_record = $this->My_model->getData($rowno,$rowperpage);
      	
      	// Pagination Configuration
      	$config['base_url'] = base_url().'index.php/News/featchNews';
      	$config['use_page_numbers'] = TRUE;
		$config['total_rows'] = $allcount;
		$config['per_page'] = $rowperpage;

		// Initialize
		$this->pagination->initialize($config);

		// Initialize $data Array
		$data['pagination'] = $this->pagination->create_links(); // create_links function help use to create link.
		$data['result'] = $users_record;
		$data['row'] = $rowno;
		// we encode our data in json format
		echo json_encode($data);
		
	}

}